import{w as t}from"./index.203dd0cf.js";const{subscribe:r,set:c,update:s}=t(0),o={subscribe:r,increment:()=>s(e=>e<1?e+.15:e),decrement:()=>s(e=>e-.1),reset:()=>c(0)},b=t(0);export{o as b,b as s};
